<?php
    use Illuminate\Support\Str;
    $event = Str::slug(Str::kebab($id));
    $open = $event . '-open';
    $close = $event . '-close';

    $personalize = tallstackui_personalization('modal', $personalization());
?>

<div x-cloak
     <?php if($id): ?> id="<?php echo e($id); ?>" <?php endif; ?>
     class="<?php echo \Illuminate\Support\Arr::toCssClasses(['relative', $configurations['zIndex']]); ?>"
     aria-labelledby="modal-title"
     role="dialog"
     aria-modal="true"
     <?php if($wire): ?>
         x-data="tallstackui_modal(<?php if ((object) ($entangle) instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e($entangle->value()); ?>')<?php echo e($entangle->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e($entangle); ?>')<?php endif; ?>)"
     <?php else: ?>
         x-data="tallstackui_modal(false)"
     <?php endif; ?>
     x-show="show"
     x-on:modal:<?php echo e($open); ?>.window="show = true;"
     x-on:modal:<?php echo e($close); ?>.window="show = false;">
    <div x-show="show"
         x-transition:enter="ease-out duration-300"
         x-transition:enter-start="opacity-0"
         x-transition:enter-end="opacity-100"
         x-transition:leave="ease-in duration-200"
         x-transition:leave-start="opacity-100"
         x-transition:leave-end="opacity-0"
         class="<?php echo \Illuminate\Support\Arr::toCssClasses([$personalize['wrapper.first'], $personalize['blur'] => $configurations['blur']]); ?>"></div>
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses($personalize['wrapper.second']); ?>">
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([$personalize['wrapper.third'], $configurations['size']]); ?>">
            <div x-show="show"
                 <?php if(!($persistent ?? $configurations['persistent'])): ?> x-on:click.outside="show = false" <?php endif; ?>
                 x-transition:enter="ease-out duration-300"
                 x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                 x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100"
                 x-transition:leave="ease-in duration-200"
                 x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100"
                 x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                 class="<?php echo \Illuminate\Support\Arr::toCssClasses([$personalize['wrapper.fourth'], $configurations['size']]); ?>">
                <?php if($title): ?>
                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses($personalize['title.wrapper']); ?>">
                        <h3 class="<?php echo \Illuminate\Support\Arr::toCssClasses($personalize['title.text']); ?>"><?php echo e($title); ?></h3>
                        <?php if (isset($component)) { $__componentOriginalcf0c10903472319464d99a08725e554d = $component; } ?>
<?php $component = TallStackUi\View\Components\Icon::resolve(['name' => 'x-mark'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(TallStackUi\View\Components\Icon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-on:click' => 'show = false','class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\Illuminate\Support\Arr::toCssClasses($personalize['title.close']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcf0c10903472319464d99a08725e554d)): ?>
<?php $component = $__componentOriginalcf0c10903472319464d99a08725e554d; ?>
<?php unset($__componentOriginalcf0c10903472319464d99a08725e554d); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses($personalize['body']); ?>">
                    <?php echo e($slot); ?>

                </div>
                <?php if($footer): ?>
                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses($personalize['footer']); ?>">
                        <?php echo e($footer); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\SIDELINE_PROJECT\InventorySystem\vendor\tallstackui\tallstackui\src/resources/views/components/modal.blade.php ENDPATH**/ ?>