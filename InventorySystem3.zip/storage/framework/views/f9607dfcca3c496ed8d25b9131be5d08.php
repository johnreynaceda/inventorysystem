<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH C:\xampp\htdocs\SIDELINE_PROJECT\InventorySystem\resources\views/livewire/category-list.blade.php ENDPATH**/ ?>