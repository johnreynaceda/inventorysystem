<div>
    <div>
        {{ $this->form }}
    </div>
    <div class="mt-5 flex justify-end">
        <x-button text="Save Sale" icon="arrow-down-on-square" loading="submit" wire:click="submit" color="indigo"
            position="right" md />
    </div>
</div>
