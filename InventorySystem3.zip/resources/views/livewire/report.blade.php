<div>
    <div>
        <h1 class="text-4xl font-black text-gray-700">&#8369;{{ number_format($sales, 2) }}</h1>
        <h1 class="font-bold text-indigo-600">SALES FOR TODAY</h1>
    </div>
    <div class="mt-6">
        {{ $this->table }}
    </div>
</div>
