<div>
    <div>
        <?php echo e($this->form); ?>

    </div>
    <div class="mt-5 flex justify-end">
        <?php if (isset($component)) { $__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5 = $component; } ?>
<?php $component = TallStackUi\View\Components\Button\Button::resolve(['text' => 'Save Sale','icon' => 'arrow-down-on-square','loading' => 'submit','color' => 'indigo','position' => 'right','md' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(TallStackUi\View\Components\Button\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'submit']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5)): ?>
<?php $component = $__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5; ?>
<?php unset($__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5); ?>
<?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\SIDELINE_PROJECT\InventorySystem\resources\views/livewire/sale.blade.php ENDPATH**/ ?>