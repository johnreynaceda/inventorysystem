<?php $__env->startSection('title', 'Dashboard'); ?>
<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div>
        <div class="grid grid-cols-4 gap-5">
            <a href=""
                class="border-2 cursor-pointer border-main bg-gray-100 rounded-xl relative overflow-hidden group p-6">
                <div class="flex justify-end">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="h-6 w-6 fill-gray-500 ">
                        <path
                            d="M16.19 2.33H7.82c-3.64 0-5.81 2.17-5.81 5.81v8.37c0 3.64 2.17 5.81 5.81 5.81h8.37c3.64 0 5.81-2.17 5.81-5.81V8.15c0-3.64-2.17-5.82-5.81-5.82z"
                            opacity=".4"></path>
                        <path
                            d="M16.4 8.21l-3.76-2.03c-.4-.21-.87-.21-1.27 0L7.61 8.21a.87.87 0 00-.44.77c0 .33.17.62.44.77l3.76 2.03c.2.11.42.16.64.16.22 0 .44-.05.64-.16l3.76-2.03a.87.87 0 00.44-.77.9.9 0 00-.45-.77zM10.74 12.47l-3.5-1.75a.867.867 0 00-.84.04c-.26.16-.41.43-.41.73v3.31c0 .57.32 1.09.83 1.34l3.5 1.75c.12.06.25.09.39.09.16 0 .31-.04.45-.13.26-.16.41-.43.41-.73v-3.31c0-.57-.31-1.08-.83-1.34zM17.59 10.76a.867.867 0 00-.84-.04l-3.5 1.75a1.5 1.5 0 00-.83 1.34v3.31c0 .3.15.57.41.73.14.09.29.13.45.13.13 0 .26-.03.39-.09l3.5-1.75c.51-.26.83-.77.83-1.34v-3.31c0-.3-.15-.57-.41-.73z">
                        </path>
                    </svg>
                </div>
                <div>
                    <p class="font-bold text-main text-3xl"><?php echo e(\App\Models\Product::count()); ?></p>
                    <p class="mt-1 text-gray-500">Products</p>
                </div>
                <div class="absolute -bottom-2 -right-2">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="h-20 opacity-10  fill-main">
                        <path
                            d="M16.19 2.33H7.82c-3.64 0-5.81 2.17-5.81 5.81v8.37c0 3.64 2.17 5.81 5.81 5.81h8.37c3.64 0 5.81-2.17 5.81-5.81V8.15c0-3.64-2.17-5.82-5.81-5.82z"
                            opacity=".4"></path>
                        <path
                            d="M16.4 8.21l-3.76-2.03c-.4-.21-.87-.21-1.27 0L7.61 8.21a.87.87 0 00-.44.77c0 .33.17.62.44.77l3.76 2.03c.2.11.42.16.64.16.22 0 .44-.05.64-.16l3.76-2.03a.87.87 0 00.44-.77.9.9 0 00-.45-.77zM10.74 12.47l-3.5-1.75a.867.867 0 00-.84.04c-.26.16-.41.43-.41.73v3.31c0 .57.32 1.09.83 1.34l3.5 1.75c.12.06.25.09.39.09.16 0 .31-.04.45-.13.26-.16.41-.43.41-.73v-3.31c0-.57-.31-1.08-.83-1.34zM17.59 10.76a.867.867 0 00-.84-.04l-3.5 1.75a1.5 1.5 0 00-.83 1.34v3.31c0 .3.15.57.41.73.14.09.29.13.45.13.13 0 .26-.03.39-.09l3.5-1.75c.51-.26.83-.77.83-1.34v-3.31c0-.3-.15-.57-.41-.73z">
                        </path>
                    </svg>
                </div>
            </a>
            <a href=""
                class="border-2 cursor-pointer border-main bg-gray-100 rounded-xl relative overflow-hidden group p-6">
                <div class="flex justify-end">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="h-6 w-6 fill-gray-500 ">
                        <path
                            d="M18.67 2h-1.9c-2.18 0-3.33 1.15-3.33 3.33v1.9c0 2.18 1.15 3.33 3.33 3.33h1.9c2.18 0 3.33-1.15 3.33-3.33v-1.9C22 3.15 20.85 2 18.67 2zM7.24 13.43h-1.9C3.15 13.43 2 14.58 2 16.76v1.9C2 20.85 3.15 22 5.33 22h1.9c2.18 0 3.33-1.15 3.33-3.33v-1.9c.01-2.19-1.14-3.34-3.32-3.34z"
                            opacity=".4"></path>
                        <path
                            d="M6.29 10.58a4.29 4.29 0 100-8.58 4.29 4.29 0 000 8.58zM17.71 22a4.29 4.29 0 100-8.58 4.29 4.29 0 000 8.58z">
                        </path>
                    </svg>
                </div>
                <div>
                    <p class="font-bold text-main text-3xl"><?php echo e(\App\Models\Category::count()); ?></p>
                    <p class="mt-1 text-gray-500">Categories</p>
                </div>
                <div class="absolute -bottom-2 -right-2">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="h-20 opacity-10  fill-main">
                        <path
                            d="M18.67 2h-1.9c-2.18 0-3.33 1.15-3.33 3.33v1.9c0 2.18 1.15 3.33 3.33 3.33h1.9c2.18 0 3.33-1.15 3.33-3.33v-1.9C22 3.15 20.85 2 18.67 2zM7.24 13.43h-1.9C3.15 13.43 2 14.58 2 16.76v1.9C2 20.85 3.15 22 5.33 22h1.9c2.18 0 3.33-1.15 3.33-3.33v-1.9c.01-2.19-1.14-3.34-3.32-3.34z"
                            opacity=".4"></path>
                        <path
                            d="M6.29 10.58a4.29 4.29 0 100-8.58 4.29 4.29 0 000 8.58zM17.71 22a4.29 4.29 0 100-8.58 4.29 4.29 0 000 8.58z">
                        </path>
                    </svg>
                </div>
            </a>
            <a href=""
                class="border-2 cursor-pointer border-main bg-gray-100 rounded-xl relative overflow-hidden group p-6">
                <div class="flex justify-end">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="h-6 w-6 fill-gray-500 ">
                        <path
                            d="M17 7.75c-.19 0-.38-.07-.53-.22a.754.754 0 010-1.06l2.05-2.05C16.76 2.92 14.49 2 12 2 6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10c0-2.49-.92-4.76-2.42-6.52l-2.05 2.05c-.15.15-.34.22-.53.22z"
                            opacity=".4"></path>
                        <path
                            d="M13.75 11.82l-1-.35V9.25h.08c.51 0 .92.45.92 1 0 .41.34.75.75.75s.75-.34.75-.75c0-1.38-1.08-2.5-2.42-2.5h-.08V7.5c0-.41-.34-.75-.75-.75s-.75.34-.75.75v.25h-.3c-1.21 0-2.2 1.02-2.2 2.28 0 1.46.85 1.93 1.5 2.16l1 .35v2.22h-.08c-.51 0-.92-.45-.92-1 0-.41-.34-.75-.75-.75s-.75.34-.75.75c0 1.38 1.08 2.5 2.42 2.5h.08v.25c0 .41.34.75.75.75s.75-.34.75-.75v-.25h.3c1.21 0 2.2-1.02 2.2-2.28 0-1.47-.85-1.94-1.5-2.16zm-3.01-1.06c-.34-.12-.49-.19-.49-.74 0-.43.32-.78.7-.78h.3v1.69l-.51-.17zm2.31 3.99h-.3v-1.69l.51.18c.34.12.49.19.49.74 0 .42-.32.77-.7.77zM22.69 1.71a.782.782 0 00-.41-.41.717.717 0 00-.29-.06h-4c-.41 0-.75.34-.75.75s.34.75.75.75h2.19l-1.67 1.67c.38.33.73.68 1.06 1.06l1.67-1.67V6c0 .41.34.75.75.75s.75-.34.75-.75V2c.01-.1-.01-.19-.05-.29z">
                        </path>
                    </svg>
                </div>
                <div>
                    <p class="font-bold text-main text-3xl">
                        &#8369;<?php echo e(number_format(\App\Models\SaleTransaction::sum('total_amount'), 2)); ?></p>
                    <p class="mt-1 text-gray-500">Sales</p>
                </div>
                <div class="absolute -bottom-2 -right-2">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="h-20 opacity-10  fill-main">
                        <path
                            d="M17 7.75c-.19 0-.38-.07-.53-.22a.754.754 0 010-1.06l2.05-2.05C16.76 2.92 14.49 2 12 2 6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10c0-2.49-.92-4.76-2.42-6.52l-2.05 2.05c-.15.15-.34.22-.53.22z"
                            opacity=".4"></path>
                        <path
                            d="M13.75 11.82l-1-.35V9.25h.08c.51 0 .92.45.92 1 0 .41.34.75.75.75s.75-.34.75-.75c0-1.38-1.08-2.5-2.42-2.5h-.08V7.5c0-.41-.34-.75-.75-.75s-.75.34-.75.75v.25h-.3c-1.21 0-2.2 1.02-2.2 2.28 0 1.46.85 1.93 1.5 2.16l1 .35v2.22h-.08c-.51 0-.92-.45-.92-1 0-.41-.34-.75-.75-.75s-.75.34-.75.75c0 1.38 1.08 2.5 2.42 2.5h.08v.25c0 .41.34.75.75.75s.75-.34.75-.75v-.25h.3c1.21 0 2.2-1.02 2.2-2.28 0-1.47-.85-1.94-1.5-2.16zm-3.01-1.06c-.34-.12-.49-.19-.49-.74 0-.43.32-.78.7-.78h.3v1.69l-.51-.17zm2.31 3.99h-.3v-1.69l.51.18c.34.12.49.19.49.74 0 .42-.32.77-.7.77zM22.69 1.71a.782.782 0 00-.41-.41.717.717 0 00-.29-.06h-4c-.41 0-.75.34-.75.75s.34.75.75.75h2.19l-1.67 1.67c.38.33.73.68 1.06 1.06l1.67-1.67V6c0 .41.34.75.75.75s.75-.34.75-.75V2c.01-.1-.01-.19-.05-.29z">
                        </path>
                    </svg>
                </div>
            </a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\SIDELINE_PROJECT\InventorySystem\resources\views/admin/index.blade.php ENDPATH**/ ?>