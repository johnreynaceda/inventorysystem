<?php
    $personalize = tallstackui_personalization('dropdown', $personalization());
    $side = str_contains($position, 'right') || str_contains($position, 'left');
    $orientation = str_contains($position, 'bottom') || str_contains($position, 'right');
?>

<div class="<?php echo \Illuminate\Support\Arr::toCssClasses($personalize['wrapper.first']); ?>"
     x-data="tallstackui_dropdown(<?php echo \Illuminate\Support\Js::from(!$static)->toHtml() ?>)">
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses($personalize['wrapper.second']); ?>" x-on:click.outside="show = false" x-ref="dropdown">
        <?php if($text): ?>
            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses($personalize['action.wrapper']); ?>">
                <span class="<?php echo \Illuminate\Support\Arr::toCssClasses($personalize['action.text']); ?>"><?php echo e($text); ?></span>
                <?php if (isset($component)) { $__componentOriginalcf0c10903472319464d99a08725e554d = $component; } ?>
<?php $component = TallStackUi\View\Components\Icon::resolve(['name' => 'chevron-down'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(TallStackUi\View\Components\Icon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['dusk' => 'open-dropdown','class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\Illuminate\Support\Arr::toCssClasses($personalize['action.icon'])),'x-on:click' => 'show = !show','x-bind:class' => '{ \'transform rotate-180\': animate && show }']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcf0c10903472319464d99a08725e554d)): ?>
<?php $component = $__componentOriginalcf0c10903472319464d99a08725e554d; ?>
<?php unset($__componentOriginalcf0c10903472319464d99a08725e554d); ?>
<?php endif; ?>
            </div>
        <?php elseif($icon): ?>
            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses($personalize['action.wrapper']); ?>">
                <?php if (isset($component)) { $__componentOriginalcf0c10903472319464d99a08725e554d = $component; } ?>
<?php $component = TallStackUi\View\Components\Icon::resolve(['icon' => $icon] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(TallStackUi\View\Components\Icon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['dusk' => 'open-dropdown','class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\Illuminate\Support\Arr::toCssClasses($personalize['action.icon'])),'x-on:click' => 'show = !show','x-bind:class' => '{ \'transform rotate-180\': animate && show }']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcf0c10903472319464d99a08725e554d)): ?>
<?php $component = $__componentOriginalcf0c10903472319464d99a08725e554d; ?>
<?php unset($__componentOriginalcf0c10903472319464d99a08725e554d); ?>
<?php endif; ?>
            </div>
        <?php else: ?>
            <?php echo $action; ?>

        <?php endif; ?>
        <div x-show="show" x-cloak
             x-transition:enter="transition duration-100 ease-out"
             x-transition:enter-start="opacity-0 <?php if($side): ?> <?php if($orientation): ?> -translate-x-2 <?php else: ?> translate-x-2 <?php endif; ?> <?php else: ?> <?php if($orientation): ?> -translate-y-2 <?php else: ?> translate-y-2 <?php endif; ?> <?php endif; ?>"
             x-transition:enter-end="opacity-100 <?php if($side): ?> translate-x-0 <?php else: ?> translate-y-0 <?php endif; ?>"
             x-transition:leave="transition duration-100 ease-in"
             x-transition:leave-start="opacity-100"
             x-transition:leave-end="opacity-0"
             x-anchor.<?php echo e($position); ?>.offset.5="$refs.dropdown"
             class="<?php echo \Illuminate\Support\Arr::toCssClasses([$personalize['wrapper.third']]); ?>"
             role="menu" aria-orientation="vertical" aria-labelledby="menu-button" tabindex="-1">
            <div class="p-1" role="none">
                <?php if($header): ?>
                    <div class="m-2">
                        <?php echo $header; ?>

                    </div>
                <?php endif; ?>
                <?php echo $slot; ?>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\SIDELINE_PROJECT\InventorySystem\vendor\tallstackui\tallstackui\src/resources/views/components/dropdown/dropdown.blade.php ENDPATH**/ ?>