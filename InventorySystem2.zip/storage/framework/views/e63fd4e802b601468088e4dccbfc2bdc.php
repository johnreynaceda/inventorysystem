<div>
    <div>
        <h1 class="text-4xl font-black text-gray-700">&#8369;<?php echo e(number_format($sales, 2)); ?></h1>
        <h1 class="font-bold text-indigo-600">SALES FOR TODAY</h1>
    </div>
    <div class="mt-6">
        <?php echo e($this->table); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\SIDELINE_PROJECT\InventorySystem\resources\views/livewire/report.blade.php ENDPATH**/ ?>