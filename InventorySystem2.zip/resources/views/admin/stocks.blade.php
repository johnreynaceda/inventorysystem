@section('title', 'Stocks')
<x-admin-layout>
    <div>
        <div class="bg-white p-10 rounded-xl">
            <livewire:stock-list />
        </div>
    </div>
</x-admin-layout>
