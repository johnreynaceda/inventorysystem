@section('title', 'Sale')
<x-admin-layout>
    <div>
        <div class="bg-white p-10 rounded-xl">
            <livewire:sale />
        </div>
    </div>
</x-admin-layout>
