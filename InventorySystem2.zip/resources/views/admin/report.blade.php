@section('title', 'Sales Report')
<x-admin-layout>
    <div>
        <div class="bg-white p-10 rounded-xl">
            <livewire:report />
        </div>
    </div>
</x-admin-layout>
