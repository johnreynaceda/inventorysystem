<div class="">
    <h1 class="text-xl font-bold text-indigo-500 underline  uppercase">Quantity Preview</h1>
    <p class="font-bold text-2xl mt-3 text-gray-700">{{ $getRecord()->quantity }}</p>
    <p class=" text-gray-700 text-sm leading-3">{{ $getRecord()->unit }}</p>
</div>
