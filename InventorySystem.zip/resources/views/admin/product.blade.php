@section('title', 'Products')
<x-admin-layout>
    <div>
        <div class="bg-white p-10 rounded-xl">
            <livewire:product-list />
        </div>
    </div>
</x-admin-layout>
