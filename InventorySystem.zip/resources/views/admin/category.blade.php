@section('title', 'Category')
<x-admin-layout>
    <div>
        <div class="bg-white p-10 rounded-xl">
            <livewire:category-list />
        </div>
    </div>
</x-admin-layout>
