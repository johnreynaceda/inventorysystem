<?php extract(collect($attributes->getAttributes())->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
@props(['class'])
<x-tallstack-ui::icon.outline.exclamation-circle :class="$class" >

{{ $slot ?? "" }}
</x-tallstack-ui::icon.outline.exclamation-circle>