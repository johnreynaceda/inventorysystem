<?php ($span = $left || $right); ?>

<!--[if BLOCK]><![endif]--><?php if($span): ?>
    <span class="inline-flex items-center gap-x-1">
<?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    <!--[if BLOCK]><![endif]--><?php if($left): ?>
        <?php echo $left; ?>

    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    <?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => 'tallstack-ui::icon.'.e($type).'.'.e($icon ?? $name).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\DynamicComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['attributes' => $attributes->class(['text-red-500' => $error])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
    <!--[if BLOCK]><![endif]--><?php if($right): ?>
        <?php echo $right; ?>

    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
<!--[if BLOCK]><![endif]--><?php if($span): ?>
    </span>
<?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
<?php /**PATH C:\xampp\htdocs\SIDELINE_PROJECT\InventorySystem\vendor\tallstackui\tallstackui\src/resources/views/components/icon.blade.php ENDPATH**/ ?>